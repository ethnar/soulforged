MEXLAR
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

Mexlar is an alien script I've been trying to nail down for a year now, and I'm finally happy with it. This is the writing ofthe red-shelled, hooting alien prudes from Points in Space. Handy for Game Masters in need of an alien/fantasy alphabet your players haven't seen before!

Mexlar is a letters-and-numbers-only font; all punctuation is the same. Caps are mirrors of lowercase.

This font is copyright 2002 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for personal, non-commercial use of any kind (including website decoration and so on). Contact me at sjohn@io.com if you're interested in a commercial license; rates will depend on the details.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 1.0